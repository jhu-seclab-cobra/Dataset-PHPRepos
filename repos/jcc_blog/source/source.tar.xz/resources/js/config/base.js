export const apiUrl = '/api/'
