# 欢迎使用 CodeFever Community 版本

### 关于 CodeFever

`CodeFever` 项目起初由 蒲公英开发者服务平台 开发和维护，项目于 2020 年 6 月上线 [https://codefever.pgyer.com/](https://codefever.pgyer.com/) 。 经过将近两年时间打磨和稳定性验证，于 2022 年 2 月开源，接受社区的考验。

`CodeFever` 开源后，开源版本称为 `CodeFever Conmmunity` 版本。同时公有云版本继续服务，继续称为 `CodeFever。`

`CodeFever Community` 由 `蒲公英开发者服务平台` 团队完整自主研发并基于 `MIT` 协议进行完整开源，拥有完全自主的知识产权，因此您可以放心使用而不必考虑是否侵犯他人权利。

`CodeFever Community` 保留了 `CodeFever` 的大部分功能，并且进行了更适合单机部署的优化。`CodeFever Community` 也会随 `CodeFever` 更新的同时接受来自社区的提交。

### 如何安装

`CodeFever` 提供 `从头开始安装` 和 `Docker 镜像安装` 两种安装方式, 可以根据自己的实际需要选择安装方式。

满足以下要求的用户和选择 `从头开始安装` 的方式进行安装。

- 学习和技术交流
- 需要做定制化修改
- `Docker 镜像安装` 不能满足处理 `Bug` 和提交 `PR` 的需求
- Docker 镜像不能在当前 `操作系统` 或 `硬件架构` 上使用

参照: [从头开始安装](../installation/install_from_scratch.md)

如果不满足上述要求，你可以选择使用 `Docker 镜像安装` 方式安装 `CodeFever Community`。

参照: [Docker 镜像安装](../installation/install_via_docker.md)

### 使用

[仓库](../reposiotry)

[仓库组](../reposiotry_group)

[管理员设置](../admin)

[Git](../git)

[常见问题](../common)

### 问题反馈

如果你在使用过程中遇到期望外的结果，欢迎提交 `Issue`。

参照: [提交问题](../contribute/bug_fix_issue.md)

如果你希望在 `CodeFever Community` 添加一些特性，也欢迎提交 `Issue`。

参照: [提交特性请求](../contribute/request_feature_issue.md)

### 贡献代码

欢迎提交 `PR`, 请确定修复 `Bug` 后或者新增 `Feature` 后进行适当的测试。

如果 `PR` 内容是问题，请先提交 `Issue` 并在提交 PR 时引用该 `Issue`。

参照: [提交问题修复](../contribute/bug_fix_pr.md)

如果 `PR` 内容是新特性，请在 `PR` 中请尽量详细描述此特性的内容，如果此 PR 是针对某个特性请求的提交，在提交 PR 时引用该 `Issue`。

参照: [提交新特性](../contribute/new_feature_pr.md)

### 贡献文档

欢迎指正文档中的错误或参加翻译工作

提交 `PR` 前请确定文档内容表述是否准确

参照: [提交文档](../contribute/doc_pr.md)