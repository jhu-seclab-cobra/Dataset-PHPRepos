<?php

return [
    'fixtures' => ['default'],
];
