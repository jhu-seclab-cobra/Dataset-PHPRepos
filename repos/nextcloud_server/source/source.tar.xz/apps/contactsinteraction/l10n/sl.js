OC.L10N.register(
    "contactsinteraction",
    {
    "Recently contacted" : "Nedavno v stiku",
    "Contacts Interaction" : "Povezave stikov",
    "Manages interaction between accounts and contacts" : "Upravlja povezave med uporabniki in stiki",
    "Collect data about accounts and contacts interactions and provide an address book for the data" : "Zbiranje podatkov o povezavah med uporabniki in stiki ter pripravljanje imenika zbranih podatkov povezav."
},
"nplurals=4; plural=(n%100==1 ? 0 : n%100==2 ? 1 : n%100==3 || n%100==4 ? 2 : 3);");
