OC.L10N.register(
    "contactsinteraction",
    {
    "Recently contacted" : "Nylig kontaktet",
    "Contacts Interaction" : "Interaksjon med kontakter",
    "Manages interaction between accounts and contacts" : "Administrerer interaksjon mellom kontoer og kontakter",
    "Collect data about accounts and contacts interactions and provide an address book for the data" : "Samle inn data om kontoer- og kontaktinteraksjoner og oppgi en adressebok for dataene"
},
"nplurals=2; plural=(n != 1);");
