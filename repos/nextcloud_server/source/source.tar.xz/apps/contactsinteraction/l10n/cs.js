OC.L10N.register(
    "contactsinteraction",
    {
    "Recently contacted" : "Nedávno kontaktovaní",
    "Contacts Interaction" : "Interakce s kontakty",
    "Manages interaction between accounts and contacts" : "Spravuje interakci mezi účty a kontakty",
    "Collect data about accounts and contacts interactions and provide an address book for the data" : "Shromažďuje data o interakcích mezi účty a kontakty a poskytuje pro tato data adresář kontaktů"
},
"nplurals=4; plural=(n == 1 && n % 1 == 0) ? 0 : (n >= 2 && n <= 4 && n % 1 == 0) ? 1: (n % 1 != 0 ) ? 2 : 3;");
