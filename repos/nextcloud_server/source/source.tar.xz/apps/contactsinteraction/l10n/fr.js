OC.L10N.register(
    "contactsinteraction",
    {
    "Recently contacted" : "Contacté récemment",
    "Contacts Interaction" : "Interaction avec les contacts",
    "Manages interaction between accounts and contacts" : "Gère l'interaction entre les comptes et les contacts",
    "Collect data about accounts and contacts interactions and provide an address book for the data" : "Collectez des données sur les interactions entre les comptes et les contacts et fournissez un répertoire pour ces données"
},
"nplurals=3; plural=(n == 0 || n == 1) ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
