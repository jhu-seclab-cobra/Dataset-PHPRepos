OC.L10N.register(
    "contactsinteraction",
    {
    "Recently contacted" : "Nedávno kontaktovaní",
    "Contacts Interaction" : "Napojenia na kontakty",
    "Manages interaction between accounts and contacts" : "Spravuje interakciu medzi účtami a kontaktmi",
    "Collect data about accounts and contacts interactions and provide an address book for the data" : "Zhromaždiť údaje o interakciách používateľov a kontaktov a poskytne adresár pre údaje"
},
"nplurals=4; plural=(n % 1 == 0 && n == 1 ? 0 : n % 1 == 0 && n >= 2 && n <= 4 ? 1 : n % 1 != 0 ? 2: 3);");
