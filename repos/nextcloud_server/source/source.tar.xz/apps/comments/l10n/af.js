OC.L10N.register(
    "comments",
    {
    "Comments" : "Kommentare",
    "You commented" : "U het kommentaar gelewer",
    "{author} commented" : "{outeur} het kommentaar gelewer",
    "You commented on %1$s" : "U het op %1$s kommentaar gelewer",
    "You commented on {file}" : "U het op {lêer} kommentaar gelewer",
    "%1$s commented on %2$s" : "%1$s het op %2$s kommentaar gelewer",
    "{author} commented on {file}" : "{outeur} het op {lêer} kommentaar gelewer",
    "<strong>Comments</strong> for files" : "<strong>Kommentare</strong> vir lêers",
    "Files app plugin to add comments to files" : "Lêertoepinprop om kommentaar op lêers te lewer",
    "Edit comment" : "Wysig kommentaar",
    "Delete comment" : "Skrap kommentaar",
    "No comments yet, start the conversation!" : "Nog geen kommentaar, begin die gesprek!",
    "Retry" : "Herprobeer",
    "Comment" : "Kommentaar",
    "_%n unread comment_::_%n unread comments_" : ["%n ongelese kommentaar","%n ongelese kommentare"]
},
"nplurals=2; plural=(n != 1);");
