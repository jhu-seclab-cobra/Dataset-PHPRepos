<?php

/*
 * NewVersionAvailable.php
 * Copyright (c) 2022 james@firefly-iii.org
 *
 * This file is part of Firefly III (https://github.com/firefly-iii).
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

declare(strict_types=1);

namespace FireflyIII\Events;

use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

/**
 * Class NewVersionAvailable
 */
class NewVersionAvailable extends Event
{
    use SerializesModels;

    public string $message;

    /**
     * Create a new event instance. This event is triggered when a new version is available.
     */
    public function __construct(string $message)
    {
        Log::debug(__METHOD__);
        $this->message = $message;
    }
}
