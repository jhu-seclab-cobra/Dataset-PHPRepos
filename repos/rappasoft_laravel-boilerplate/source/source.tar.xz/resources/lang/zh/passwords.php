<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Password Reset Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */

    'reset' => '密码重置成功！',
    'sent' => '密码重置邮件已发送！',
    'throttled' => 'Please wait before retrying.',
    'token' => '密码重置令牌无效。',
    'user' => '找不到该邮箱对应的用户。',
];
