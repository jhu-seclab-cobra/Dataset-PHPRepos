<?php
/*
 * execacb.php
 *
 * part of pfSense (https://www.pfsense.org)
 * Copyright (c) 2004-2013 BSD Perimeter
 * Copyright (c) 2013-2016 Electric Sheep Fencing
 * Copyright (c) 2014-2025 Rubicon Communications, LLC (Netgate)
 * Copyright (c) 2009 Erik Kristensen
 * All rights reserved.
 *
 * originally part of m0n0wall (http://m0n0.ch/wall)
 * Copyright (c) 2003-2004 Manuel Kasper <mk@neon1.net>.
 * All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * This script is called by cron to perform a periodic scheduled backup of the
 * current configuration using the AutoConfigBackup service.
 */

require_once("acb.inc");

if (acb_enabled()) {
	if (is_acb_upload_needed()) {
		write_config(gettext('Scheduled Backup via AutoConfigBackup'));
		acb_backup_stage_upload();
	} else {
		log_error(gettext('Skipping AutoConfigBackup scheduled backup (no changes since previous backup)'));
	}
}
