Some configuration options
