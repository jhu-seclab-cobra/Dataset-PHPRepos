Quelques options de configuration
