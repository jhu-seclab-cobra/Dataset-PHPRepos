<?php
/*
 * deprecated
 */