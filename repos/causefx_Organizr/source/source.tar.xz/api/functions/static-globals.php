<?php

trait StaticFunctions
{

}