<?php

trait PluginFunctions
{

}