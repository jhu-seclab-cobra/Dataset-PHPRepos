<?php

trait NetDataFunctions
{

}
