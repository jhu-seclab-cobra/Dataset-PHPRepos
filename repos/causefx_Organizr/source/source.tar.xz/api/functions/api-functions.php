<?php

trait ApiFunctions
{
	// Nothing
}
