OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Aniversários do contacto",
    "User unknown" : "Utilizador desconhecido",
    "User disabled" : "Utilizador desativado",
    "Personal" : "Pessoal",
    "Contacts" : "Contactos",
    "Technical details" : "Detalhes técnicos",
    "Remote Address: %s" : "Endereço remoto: %s",
    "Request ID: %s" : "Id. do pedido: %s"
},
"nplurals=3; plural=(n == 0 || n == 1) ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
