<?php
return [
    'note' => 'Note',
    'notes' => 'Notes',

    'add' => 'Ajouter Note',
    'show' => 'Afficher Note',
    'edit' => 'Éditer Note',
    'update' => 'Mettre à jour Note',
    'delete' => 'Supprimer Note',

    'public' => 'Note publique',
    'internal' => 'Note interne',
    'private' => 'Note Privée',

    'note_content' => 'Contenu Note',

    'added_successfully' => 'Note ajoutée avec succès.',
    'updated_successfully' => 'Note mise à jour avec succès.',
    'deleted_successfully' => 'Note déplacée avec succès vers la corbeille.',
    'deletion_error' => 'La note n\'a pas pu être déplacée dans la corbeille.',
];
