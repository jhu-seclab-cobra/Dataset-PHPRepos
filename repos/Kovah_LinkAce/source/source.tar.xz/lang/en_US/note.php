<?php
return [
    'note' => 'Note',
    'notes' => 'Notes',

    'add' => 'Add Note',
    'show' => 'Show Note',
    'edit' => 'Edit Note',
    'update' => 'Update Note',
    'delete' => 'Delete Note',

    'public' => 'Public Note',
    'internal' => 'Internal Note',
    'private' => 'Private Note',

    'note_content' => 'Note Content',

    'added_successfully' => 'Note added successfully.',
    'updated_successfully' => 'Note updated successfully.',
    'deleted_successfully' => 'Note successfully moved to the trash.',
    'deletion_error' => 'Note could not be moved to the trash.',
];
