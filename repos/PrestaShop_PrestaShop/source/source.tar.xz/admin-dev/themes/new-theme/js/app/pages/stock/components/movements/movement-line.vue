<!--**
 * Copyright since 2007 PrestaShop SA and Contributors
 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/OSL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to https://devdocs.prestashop.com/ for more information.
 *
 * @author    PrestaShop SA and Contributors <contact@prestashop.com>
 * @copyright Since 2007 PrestaShop SA and Contributors
 * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
 *-->
<template>
  <tr>
    <td>
      {{ product.product_id }}
    </td>
    <td>
      <div class="d-flex align-items-center">
        <PSMedia
          class="d-flex align-items-center"
          :thumbnail="thumbnail"
        >
          <p>
            {{ product.product_name }}
            <small v-if="hasCombination"><br>
              {{ product.combination_name }}
            </small>
          </p>
        </PSMedia>
      </div>
    </td>
    <td>
      {{ product.product_reference }}
    </td>
    <td>
      <a
        v-if="orderLink"
        :href="orderLink"
        target="_blank"
      >
        {{ product.movement_reason }}
      </a>
      <span v-else>{{ product.movement_reason }}</span>
    </td>
    <td class="text-sm-center">
      <span
        class="qty-number"
        :class="{'is-positive' : isPositive}"
      >
        <span v-if="isPositive">+</span>
        <span v-else>-</span>
        {{ qty }}
      </span>
    </td>
    <td class="text-sm-center">
      {{ product.date_add_formatted }}
    </td>
    <td>
      {{ employeeName }}
    </td>
  </tr>
</template>

<script lang="ts">
  import PSMedia from '@app/widgets/ps-media.vue';
  import productDesc from '@app/pages/stock/mixins/product-desc';
  import {defineComponent, PropType} from 'vue';
  import {StockMovement} from './index.vue';

  export default defineComponent({
    props: {
      product: {
        type: Object as PropType<StockMovement>,
        required: true,
      },
    },
    mixins: [productDesc],
    computed: {
      qty(): number {
        return this.product.physical_quantity;
      },
      employeeName(): string {
        return `${this.product.employee_firstname} ${this.product.employee_lastname}`;
      },
      isPositive(): boolean {
        return this.product.sign > 0;
      },
      orderLink(): string | null {
        return this.product.order_link !== 'N/A' ? this.product.order_link : null;
      },
    },
    components: {
      PSMedia,
    },
  });
</script>
