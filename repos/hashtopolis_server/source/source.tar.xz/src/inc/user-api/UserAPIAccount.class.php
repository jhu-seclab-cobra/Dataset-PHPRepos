<?php

class UserAPIAccount extends UserAPIBasic {
  public function execute($QUERY = array()) {
    try {
      switch ($QUERY[UQuery::REQUEST]) {
        case USectionAccount::GET_INFORMATION:
          $this->getInformation($QUERY);
          break;
        case USectionAccount::SET_EMAIL:
          $this->setEmail($QUERY);
          break;
        case USectionAccount::SET_SESSION_LENGTH:
          $this->setSessionLenght($QUERY);
          break;
        case USectionAccount::CHANGE_PASSWORD:
          $this->changePassword($QUERY);
          break;
        default:
          $this->sendErrorResponse($QUERY[UQuery::SECTION], "INV", "Invalid section request!");
      }
    }
    catch (HTException $e) {
      $this->sendErrorResponse($QUERY[UQueryTask::SECTION], $QUERY[UQueryTask::REQUEST], $e->getMessage());
    }
  }
  
  /**
   * @param array $QUERY
   * @throws HTException
   */
  private function changePassword($QUERY) {
    if (!isset($QUERY[UQueryAccount::OLD_PASS]) || !isset($QUERY[UQueryAccount::NEW_PASS])) {
      throw new HTException("Invalid query!");
    }
    AccountUtils::changePassword($QUERY[UQueryAccount::OLD_PASS], $QUERY[UQueryAccount::NEW_PASS], $QUERY[UQueryAccount::NEW_PASS], $this->user);
    $this->sendSuccessResponse($QUERY);
  }
  
  /**
   * @param array $QUERY
   * @throws HTException
   */
  private function setSessionLenght($QUERY) {
    if (!isset($QUERY[UQueryAccount::SESSION_LENGTH])) {
      throw new HTException("Invalid query!");
    }
    AccountUtils::updateSessionLifetime($QUERY[UQueryAccount::SESSION_LENGTH], $this->user);
    $this->sendSuccessResponse($QUERY);
  }
  
  /**
   * @param array $QUERY
   * @throws HTException
   */
  private function setEmail($QUERY) {
    if (!isset($QUERY[UQueryAccount::EMAIL])) {
      throw new HTException("Invalid query!");
    }
    AccountUtils::setEmail($QUERY[UQueryAccount::EMAIL], $this->user);
    $this->sendSuccessResponse($QUERY);
  }
  
  /**
   * @param array $QUERY
   */
  private function getInformation($QUERY) {
    $response = [
      UResponseAccount::SECTION => $QUERY[UQueryAccount::SECTION],
      UResponseAccount::REQUEST => $QUERY[UQueryAccount::REQUEST],
      UResponseAccount::RESPONSE => UValues::OK,
      UResponseAccount::USER_ID => (int)$this->user->getId(),
      UResponseAccount::EMAIL => $this->user->getEmail(),
      UResponseAccount::RIGHT_GROUP_ID => (int)$this->user->getRightGroupId(),
      UResponseAccount::SESSION_LENGTH => (int)$this->user->getSessionLifetime()
    ];
    $this->sendResponse($response);
  }
}