/* Swedish translation for the jQuery Timepicker Addon */
/* Written by Nevon */
(function($) {
	$.timepicker.regional['sv'] = {
		timeOnlyTitle: 'Välj en tid',
		timeText: 'Tid',
		hourText: 'Timme',
		minuteText: 'Minut',
		secondText: 'Sekund',
		millisecText: 'Millisekund',
		microsecText: 'Mikrosekund',
		timezoneText: 'Tidszon',
		currentText: 'Nu',
		closeText: 'Stäng',
		timeFormat: 'HH:mm',
		timeSuffix: '',
		amNames: ['AM', 'A'],
		pmNames: ['PM', 'P'],
		isRTL: false
	};
	$.timepicker.setDefaults($.timepicker.regional['sv']);
})(jQuery);
