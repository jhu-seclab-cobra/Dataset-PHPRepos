<?php

return [
    'likes' => 'Likes',
];
