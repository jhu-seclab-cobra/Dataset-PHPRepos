/**
 * Lithuanian (UTF-8) initialisation for the jQuery UI date picker plugin.
 *
 * @author Arturas Paleicikas <arturas@avalon.lt>
 */
jQuery(function($){
    $.datepicker.regional['lt'] = {clearText: 'Išvalyti', clearStatus: '',
        closeText: 'Uždaryti', closeStatus: '',
        prevText: '&lt;Atgal',  prevStatus: '',
        nextText: 'Pirmyn&gt;', nextStatus: '',
        currentText: 'Šiandien', currentStatus: '',
        monthNames: ['Sausis','Vasaris','Kovas','Balandis','Gegužė','Birželis',
        'Liepa','Rugpjūtis','Rugsėjis','Spalis','Lapkritis','Gruodis'],
        monthNamesShort: ['Sau','Vas','Kov','Bal','Geg','Bir',
        'Lie','Rugp','Rugs','Spa','Lap','Gru'],
        monthStatus: '', yearStatus: '',
        weekHeader: '', weekStatus: '',
        dayNames: ['sekmadienis','pirmadienis','antradienis','trečiadienis','ketvirtadienis','penktadienis','šeštadienis'],
        dayNamesShort: ['sek','pir','ant','tre','ket','pen','šeš'],
        dayNamesMin: ['Se','Pr','An','Tr','Ke','Pe','Še'],
        dayStatus: 'DD', dateStatus: 'D, M d',
        dateFormat: 'yy-mm-dd', firstDay: 1,
        initStatus: '', isRTL: false};
    $.datepicker.setDefaults($.datepicker.regional['lt']);
});