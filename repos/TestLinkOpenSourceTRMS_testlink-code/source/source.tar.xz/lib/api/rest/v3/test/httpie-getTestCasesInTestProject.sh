. ./setURI.sh
APIKEY="Apikey:c94048220527a3d038db5c19e1156c08"
ACTION=testprojects/12/testcases
http GET $URI$ACTION $APIKEY
