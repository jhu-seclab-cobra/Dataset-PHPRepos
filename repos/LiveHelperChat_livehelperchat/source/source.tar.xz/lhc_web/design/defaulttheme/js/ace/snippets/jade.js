ace.define("ace/snippets/jade",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="jade"});                (function() {
                    ace.require(["ace/snippets/jade"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            