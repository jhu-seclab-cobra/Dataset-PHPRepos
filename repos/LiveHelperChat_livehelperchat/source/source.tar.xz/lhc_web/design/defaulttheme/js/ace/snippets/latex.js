ace.define("ace/snippets/latex",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="latex"});                (function() {
                    ace.require(["ace/snippets/latex"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            