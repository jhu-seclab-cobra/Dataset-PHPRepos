ace.define("ace/snippets/d",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="d"});                (function() {
                    ace.require(["ace/snippets/d"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            