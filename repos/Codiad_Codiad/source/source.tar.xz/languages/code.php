<?php
$languages = array(
    "en" => "english",
    "fr" => "français",
    "it" => "italiano",
    "ru" => "русский",
    "de" => "deutsch",
    "es" => "español",
    "pt" => "português",
    "ro" => "romanian",
    "hu" => "magyar",
    "sv" => "swedish",
    "cn" => "简体中文",
    "pl" => "polish",
    "cz" => "česky",
    "sk" => "slovak",
    "sr" => "српски",
    "bg" => "Български",
    "tr" => "Türkçe",
    "ja" => "日本語",
    "nl" => "Nederlands"
);
?>
