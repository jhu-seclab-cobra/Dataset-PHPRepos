Plugins
=======

The official ThinkUp distribution comes with a set of approved plugins. Click on Settings > Plugins to configure them.

.. toctree::
   :maxdepth: 1

   expandurls
   facebook
   insightsgenerator
   instagram
   twitter/index
