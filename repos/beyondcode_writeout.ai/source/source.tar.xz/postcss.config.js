module.exports = {
    plugins: {
        tailwindcss: {},
    },
};
