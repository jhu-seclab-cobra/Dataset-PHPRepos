<?php
/**
 * Iban query field file.
 *
 * @package   App
 *
 * @copyright YetiForce S.A.
 * @license   YetiForce Public License 6.5 (licenses/LicenseEN.txt or yetiforce.com)
 * @author    Adrian Kon <a.kon@yetiforce.com>
 */

namespace App\Conditions\RecordFields;

/**
 * Iban query field class.
 */
class IbanField extends BaseField
{
}
