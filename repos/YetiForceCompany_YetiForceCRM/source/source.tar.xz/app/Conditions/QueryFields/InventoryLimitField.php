<?php

namespace App\Conditions\QueryFields;

/**
 * InventoryLimit Query Field Class.
 *
 * @package UIType
 *
 * @copyright YetiForce S.A.
 * @license   YetiForce Public License 6.5 (licenses/LicenseEN.txt or yetiforce.com)
 * @author    Tomasz Kur <t.kur@yetiforce.com>
 */
class InventoryLimitField extends PicklistField
{
}
