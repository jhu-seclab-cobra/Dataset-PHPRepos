<?php

/**
 * @package    Grav\Framework\Session
 *
 * @copyright  Copyright (c) 2015 - 2025 Trilby Media, LLC. All rights reserved.
 * @license    MIT License; see LICENSE file for details.
 */

namespace Grav\Framework\Session\Exceptions;

use RuntimeException;

/**
 * Class SessionException
 * @package Grav\Framework\Session\Exceptions
 */
class SessionException extends RuntimeException
{
}
