<?php

/**
 * @package    Grav\Framework\RequestHandler
 *
 * @copyright  Copyright (c) 2015 - 2025 Trilby Media, LLC. All rights reserved.
 * @license    MIT License; see LICENSE file for details.
 */

declare(strict_types=1);

namespace Grav\Framework\RequestHandler\Exception;

/**
 * Class NotHandledException
 * @package Grav\Framework\RequestHandler\Exception
 */
class NotHandledException extends NotFoundException
{
}
