<?php
/**
 * ApiException.php
 *
 * -Description-
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * @link       https://www.librenms.org
 *
 * @copyright  2019 Tony Murray
 * @author     Tony Murray <murraytony@gmail.com>
 */

namespace LibreNMS\Exceptions;

class ApiClientException extends \Exception
{
    /** @var array */
    private $output;

    /**
     * @param  string  $message
     * @param  array  $output
     */
    public function __construct($message = '', $output = [])
    {
        parent::__construct($message, 0, null);
        $this->output = $output;
    }

    public function getOutput(): array
    {
        return $this->output;
    }
}
