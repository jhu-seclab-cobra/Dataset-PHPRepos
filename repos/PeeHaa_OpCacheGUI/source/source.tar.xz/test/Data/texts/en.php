<?php

$texts = [
    'foo' => 'bar',
];
