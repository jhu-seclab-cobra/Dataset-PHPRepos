<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Password Reset Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */

    'password' => 'رمز عبور باید حداقل شش کاراکتر و مطابقت داشته باشد.',
    'reset' => 'بازگردانی کلمه عبور انجام شد!',
    'sent' => 'ایمیل یاد آور رمز عبور ارسال شد!',
    'token' => 'مشخصه ی بازنشاندن رمز عبور اشتباه است.',
    'user' => "کاربری با این ایمیل آدرس یافت نشد.",

];
