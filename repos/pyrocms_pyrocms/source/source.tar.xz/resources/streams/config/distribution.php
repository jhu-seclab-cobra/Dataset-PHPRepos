<?php

return [
    'name'        => 'PyroCMS',
    'description' => 'Build better Laravel websites and applications faster with Pyro.',
    'version'     => 'v3.9',
];
