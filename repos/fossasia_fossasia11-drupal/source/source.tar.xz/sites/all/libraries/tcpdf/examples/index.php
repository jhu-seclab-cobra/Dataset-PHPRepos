<?php
echo '<'.'?'.'xml version="1.0" encoding="UTF-8"'.'?'.'>';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr">

<head>
<title>TCPDF Examples</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="aiocp_level" content="0" />
<meta name="description" content="TCPDF is a PHP class for generating PDF documents on the fly" />
<meta name="author" content="Nicola Asuni" />
<meta name="keywords" content="Examples, TCPDF, PDF, PHP class" />
</head>

<body>

<h1>TCPDF Examples</h1>

<ol>
<li>Simple PDF with default Header and Footer: [<a href="example_001.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Simple PDF without Header and Footer: [<a href="example_002.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Custom Header and Footer: [<a href="example_003.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Cell stretching: [<a href="example_004.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Multicell: [<a href="example_005.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>WriteHTML and RTL support: [<a href="example_006.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Independent columns with WriteHTMLCell: [<a href="example_007.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>External UTF-8 text file: [<a href="example_008.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Image: [<a href="example_009.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Multiple columns: [<a href="example_010.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Colored Tables: [<a href="example_011.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Graphic Functions: [<a href="example_012.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Graphic Transformations: [<a href="example_013.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Javascript and Forms: [<a href="example_014.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Bookmarks (Table of Content): [<a href="example_015.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Document Encryption: [<a href="example_016.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Independent columns with MultiCell: [<a href="example_017.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Persian and Arabic language on RTL document: [<a href="example_018.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Non unicode / Alternative config file: [<a href="example_019.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Multicell complex alignment: [<a href="example_020.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>writeHTML alignment: [<a href="example_021.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>CMYK colors: [[<a href="example_022.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Page Groups: [<a href="example_023.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Object Visibility: [<a href="example_024.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Object Transparency: [<a href="example_025.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Text Rendering Modes and Text Clipping: [<a href="example_026.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Barcodes: [<a href="example_027.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Multiple page formats: [<a href="example_028.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Set PDF viewer display preferences: [<a href="example_029.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Colour gradients: [<a href="example_030.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Pie Chart Graphic: [<a href="example_031.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>EPS/AI vectorial image: [<a href="example_032.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Mixed font types (TrueType Unicode, core, CID-0): [<a href="example_033.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Clipping masks: [<a href="example_034.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Line styles with cells and multicells: [<a href="example_035.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Text Annotations: [<a href="example_036.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Spot Colors: [<a href="example_037.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>NON-embedded CID-0 CJK font: [<a href="example_038.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>HTML Justification: [<a href="example_039.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Booklet (double-sided pages): [<a href="example_040.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>File attachment: [<a href="example_041.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Image with Alpha Channel Transparency: [<a href="example_042.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Disk caching: [<a href="example_043.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Move and delete page: [<a href="example_044.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Table Of Content with Bookmarks: [<a href="example_045.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Text hyphenation: [<a href="example_046.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Transactions and UNDO: [<a href="example_047.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Table header and rowspan: [<a href="example_048.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>TCPDF methods in HTML: [<a href="example_049.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>2D Barcode (QR Code): [<a href="example_050.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Full page background: [<a href="example_051.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Digital Signature Certification: [<a href="example_052.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Javascript functions: [<a href="example_053.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>XHTML Form: [<a href="example_054.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Font Dump: [<a href="example_055.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Crop Marks and Registration Marks: [<a href="example_056.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
<li>Cell vertical alignments: [<a href="example_057.php" title="PDF [new window]" target="_blank">PDF</a>]</li>
</ol>

</body>
</html>
