<?php
# MantisBT - A PHP based bugtracking system

# MantisBT is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# MantisBT is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with MantisBT.  If not, see <http://www.gnu.org/licenses/>.

namespace Mantis\Exceptions;

use Throwable;

/**
 * A base exception for all Mantis exceptions.
 */
class MantisException extends \Exception {
	/**
	 * @var array array of parameters for localized exception message.
	 */
	protected $params;

    /**
     * Constructor
     *
     * @param string $p_message The internal non-localized error message.
     * @param integer $p_code The Mantis error code.
     * @param array $p_params Localized error message parameters.
     * @param Throwable $p_previous The inner exception.
     * @return void
     */
	function __construct( $p_message, $p_code, $p_params = array(), ?Throwable $p_previous = null ) {
		parent::__construct( $p_message, $p_code, $p_previous );
		$this->params = $p_params;
	}

	/**
	 * Get parameters for exception localized string.
	 *
	 * @return array The parameters.
	 */
	function getParams() {
		return $this->params;
	}
}