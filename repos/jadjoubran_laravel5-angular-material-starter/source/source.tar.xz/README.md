## Laravel 5.3 Angular Material Starter

[![Latest Stable Version](https://poser.pugx.org/jadjoubran/laravel5-angular-material-starter/v/stable)](https://packagist.org/packages/jadjoubran/laravel5-angular-material-starter)
[![Latest Unstable Version](https://poser.pugx.org/jadjoubran/laravel5-angular-material-starter/v/unstable)](https://packagist.org/packages/jadjoubran/laravel5-angular-material-starter)
[![Build Status](https://travis-ci.org/jadjoubran/laravel5-angular-material-starter.svg?branch=master)](https://travis-ci.org/jadjoubran/laravel5-angular-material-starter)
[![StyleCI](https://styleci.io/repos/34944760/shield?style=flat)](https://styleci.io/repos/34944760)
[![Code Climate](https://codeclimate.com/github/jadjoubran/laravel5-angular-material-starter/badges/gpa.svg)](https://codeclimate.com/github/jadjoubran/laravel5-angular-material-starter)
[![License](https://poser.pugx.org/jadjoubran/laravel5-angular-material-starter/license)](https://packagist.org/packages/jadjoubran/laravel5-angular-material-starter)
[![Join the chat at https://gitter.im/jadjoubran/laravel5-angular-material-starter](https://badges.gitter.im/jadjoubran/laravel5-angular-material-starter.svg)](https://gitter.im/jadjoubran/laravel5-angular-material-starter?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

![Laravel & Angular](http://i.imgur.com/CwQy3Il.png)


## Demo

An online <a href="http://www.laravel-angular.io/" target="_blank">demo</a> is available.


## Angular (2+) update

While this starter used to be an excellent starting point for Laravel 5 & Angular 1.x, using Angular 1.x results in large JavaScript bundles which makes mobile experience slow.  
Thus it's recommended to upgrade to Angular (2+).
You can use the shiny new [Laravel & Angular package](https://github.com/jadjoubran/laravel-angular)

## Docs

[View Latest Docs](http://laravel-angular.readme.io/) for installation steps & tutorials.


Running on 3.2? Here are the [3.2 Docs](https://laravel-angular.readme.io/v3.2)


## Screencasts

Screencasts on [Youtube](https://www.youtube.com/c/LaravelAngularMaterialStarter).


## Issues, questions and feature requests
Open a new issue, I'd love to help.



## Do It Yourself (Outdated)

A nice article on <a href="http://www.sitepoint.com/flexible-and-easily-maintainable-laravel-angular-material-apps/" target="_blank">sitepoint</a> that explains the first few versions of this repository. Recommended read if you're not familiar with the underlying technologies.

## Community translations

- [v3.4 - Chinese](https://github.com/ArrayZoneYour/Laravel-Angular-Material-Doc-Chinese)

## Contributing

Thank you for contributing to this repository.

Here are the guidelines:

1. If you are adding/modifying backend functionality, make sure to include the appropriate `test`. Let me know if you need help writing the test.
