<?php

use Carbon\Carbon;

return [

    'build_date' => Carbon::parse('2025-02-23'),

    'build_version' => 'v1.2.5',

    /**
     * General settings.
     */
    'content_width' => env('CONTENT_WIDTH', '7xl'),

    'prune_results_older_than' => (int) env('PRUNE_RESULTS_OLDER_THAN', 0),

    'public_dashboard' => env('PUBLIC_DASHBOARD', false),

    /**
     * Speedtest settings.
     */
    'schedule' => env('SPEEDTEST_SCHEDULE', false),

    'servers' => env('SPEEDTEST_SERVERS'),

    'blocked_servers' => env('SPEEDTEST_BLOCKED_SERVERS'),

    'interface' => env('SPEEDTEST_INTERFACE'),

    /**
     * IP filtering settings.
     */
    'skip_ips' => env('SPEEDTEST_SKIP_IPS', ''),

    /**
     * Threshold settings.
     */

     'threshold_enabled' => env('THRESHOLD_ENABLED', false),

     'threshold_download' => env('THRESHOLD_DOWNLOAD', 0),

     'threshold_upload' => env('THRESHOLD_UPLOAD', 0),

     'threshold_ping' => env('THRESHOLD_PING', 0) ,
];
