rootProject.name = "benchmark"
