export default {
  GET: () => {},
};
