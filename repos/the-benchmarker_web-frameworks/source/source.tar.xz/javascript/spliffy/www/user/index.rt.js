export default {
  POST: () => {},
};
